import React from 'react';
import './App.css';
import CuriosityComponent from './components/CuriosityComponent';


function App() {
    return <CuriosityComponent/>;
}

export default App;