package oraclecloudnative.ocilab.curiosity.curiosity.serviceclients;
/*

Publish information about user requests to OCIStreaming !
*/
public class ChampionshipServicePublisher {
    
}
