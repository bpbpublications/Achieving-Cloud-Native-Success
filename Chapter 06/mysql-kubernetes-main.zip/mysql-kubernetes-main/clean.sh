kubectl delete ns mysql

kubectl delete pv mysql-db-pv-volume
