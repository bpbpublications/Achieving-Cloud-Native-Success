## Build with Gradle:

./gradlew build


## Execute from the command line: 

java -jar cloudnativebasic-0.0.1-SNAPSHOT.jar
