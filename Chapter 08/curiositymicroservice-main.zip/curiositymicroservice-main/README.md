curiositymicroservice.git


This is the code for the backend in the microservice version

Fernando Harris
---

**Manual deployment**

Install the application manually

[Manual deployment](./manual-deployment.md)

**Automated deployment**

Setup a local full DevOps ecosystem with Jenkins CI/CD pipelines, Gogs as a source code server repository and Registry to manage container images life cycle.

[Automated deployment](./automatic-deployment.md)

