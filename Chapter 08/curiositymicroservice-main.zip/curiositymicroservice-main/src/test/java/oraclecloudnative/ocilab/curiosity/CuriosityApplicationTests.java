package oraclecloudnative.ocilab.curiosity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CuriosityApplicationTests {

	@Test
	void contextLoads() {
	}

}
