package oraclecloudnative.ocilab.curiosity.curiosity.pagedetails;


import java.util.Map;

import lombok.*;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
public class Pages {
     Map<String, Object> pageDetails;
}
