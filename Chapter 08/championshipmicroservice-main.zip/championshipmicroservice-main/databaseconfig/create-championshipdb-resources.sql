#DROP DATABASE IF EXISTS championshipdb;
#DROP USER IF EXISTS championship;
#CREATE DATABASE championshipdb;
#CREATE USER 'championship'@'%' IDENTIFIED BY 'Welcome#1';
#GRANT ALL PRIVILEGES ON championshipdb.* TO 'championship'@'%'; 

#CREATE USER 'championship'@'%' IDENTIFIED BY 'Welcome#1';
#GRANT ALL PRIVILEGES ON championshipdb.* TO 'curiosity'@'%'; 
SHOW DATABASES;

