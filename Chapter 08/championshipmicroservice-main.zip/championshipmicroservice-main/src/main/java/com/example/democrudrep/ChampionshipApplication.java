package com.example.democrudrep;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;




@SpringBootApplication
public class ChampionshipApplication {



	public static void main(String[] args) {
		SpringApplication.run(ChampionshipApplication.class, args);
		System.out.println("I AM HERE !!!!!!!->");
		//SentQueryPageEvent sentQueryPageEvent = new SentQueryPageEvent(124L, 2L, "Fer", "originalQuery", "query");

		
	}

}
