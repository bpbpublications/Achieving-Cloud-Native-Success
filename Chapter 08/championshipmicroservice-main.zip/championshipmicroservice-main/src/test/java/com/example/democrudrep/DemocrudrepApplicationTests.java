package com.example.democrudrep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemocrudrepApplicationTests {

	@Test
	void contextLoads() {
	}

}
